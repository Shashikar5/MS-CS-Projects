Linear Regression Project
-----------------------------------------------------------------------------------------------------------------------
You just got some contract work with an Ecommerce company based in New York City that sells clothing online 
but they also have in-store style and clothing advice sessions. Customers come in to the store, have sessions/meetings 
with a personal stylist, then they can go home and order either on a mobile app or website for the clothes they want.

The company is trying to decide whether to focus their efforts on their mobile app experience or their website