ABOUT
------------------------------------------------------------------------------
Made a Blood Bank database ,Created all tables required for it , 
converted it to a relational schema , connected them using 
foreign key(SQL code) and made a ER diagram for it.