Objectives
---------------------
Implementation and analysis of image compression algo like LZW , huffmans 
and executing them in a distributed environment with more accuracy and less time.